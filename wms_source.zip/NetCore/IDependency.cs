﻿namespace YL.NetCore
{
    /// <summary>
    /// 依赖注入 继承该接口自动注册
    /// </summary>
    public interface IDependency
    {
    }
}