﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;

namespace YL.Core.Orm.SqlSugar
{
    public static class SqlQueryableExt
    {
        //public static ISugarQueryable<T> SetQueryableOrder<T>(this ISugarQueryable<T> query, string sort, string order)
        //{
        //}
    }
}