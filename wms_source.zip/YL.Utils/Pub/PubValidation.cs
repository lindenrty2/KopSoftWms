﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YL.Utils.Pub
{
    public class PubValidation
    {
    }
}