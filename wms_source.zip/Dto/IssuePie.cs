﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YL.Core.Dto
{
    public class IssuePie
    {
        public string Description { get; set; }
        public string Count { get; set; }
    }
}