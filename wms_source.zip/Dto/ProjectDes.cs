﻿namespace YL.Core.Dto
{
    /// <summary>
    /// 系统描述，从配置文件中读取
    /// </summary>
    public class ProjectDes
    {
        public string Project { get; set; }
        public string[] Content { get; set; }
    }
}