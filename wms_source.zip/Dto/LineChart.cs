﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YL.Core.Dto
{
    public class LineChart
    {
        public string DeptName { get; set; }
        public string PlatformNo { get; set; }
        public string DateMonth { get; set; }
        public string Count { get; set; }
    }
}