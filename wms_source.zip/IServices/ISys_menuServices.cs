using YL.Core.Entity;

namespace IServices
{
    public interface ISys_menuServices : IBaseServices<Sys_menu>
    {
    }
}