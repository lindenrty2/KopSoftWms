using YL.Core.Entity;

namespace IServices
{
    public interface ISys_rolemenuServices : IBaseServices<Sys_rolemenu>
    {
    }
}