﻿using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_supplierRepository : IBaseRepository<Wms_supplier>
    {
    }
}
