using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_inventoryRepository : IBaseRepository<Wms_inventory>
    {
    }
}