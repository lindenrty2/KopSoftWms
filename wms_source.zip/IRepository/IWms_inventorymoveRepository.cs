using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_inventorymoveRepository : IBaseRepository<Wms_inventorymove>
    {
    }
}