using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_deviceRepository : IBaseRepository<Wms_device>
    {
    }
}