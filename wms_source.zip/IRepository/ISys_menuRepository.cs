using YL.Core.Entity;

namespace IRepository
{
    public interface ISys_menuRepository : IBaseRepository<Sys_menu>
    {
    }
}