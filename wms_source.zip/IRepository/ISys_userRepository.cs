using YL.Core.Entity;

namespace IRepository
{
    public interface ISys_userRepository : IBaseRepository<Sys_user>
    {
    }
}