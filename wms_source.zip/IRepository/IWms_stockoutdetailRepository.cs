using YL.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace IRepository
{
   public interface IWms_stockoutdetailRepository : IBaseRepository<Wms_stockoutdetail>
    {
    }
}