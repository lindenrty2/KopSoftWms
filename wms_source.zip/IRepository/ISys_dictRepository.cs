using YL.Core.Entity;

namespace IRepository
{
    public interface ISys_dictRepository : IBaseRepository<Sys_dict>
    {
    }
}