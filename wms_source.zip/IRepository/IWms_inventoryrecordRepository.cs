using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_inventoryrecordRepository : IBaseRepository<Wms_inventoryrecord>
    {
    }
}