using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_warehouseRepository : IBaseRepository<Wms_warehouse>
    {
    }
}