using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_invmovedetailRepository : IBaseRepository<Wms_invmovedetail>
    {
    }
}