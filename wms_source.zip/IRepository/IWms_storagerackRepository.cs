using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_storagerackRepository : IBaseRepository<Wms_storagerack>
    {
    }
}