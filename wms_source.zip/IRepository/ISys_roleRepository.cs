using YL.Core.Entity;

namespace IRepository
{
    public interface ISys_roleRepository : IBaseRepository<Sys_role>
    {
    }
}