﻿using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_CustomerRepository : IBaseRepository<Wms_Customer>
    {
    }
}
