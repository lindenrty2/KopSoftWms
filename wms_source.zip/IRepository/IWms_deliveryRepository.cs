using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_deliveryRepository : IBaseRepository<Wms_delivery>
    {
    }
}