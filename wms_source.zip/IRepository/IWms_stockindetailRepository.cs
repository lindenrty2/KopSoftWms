using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_stockindetailRepository : IBaseRepository<Wms_stockindetail>
    {
    }
}