using YL.Core.Entity;

namespace IRepository
{
    public interface ISys_serialnumRepository : IBaseRepository<Sys_serialnum>
    {
    }
}