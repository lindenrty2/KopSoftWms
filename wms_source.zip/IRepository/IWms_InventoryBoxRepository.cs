using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_inventoryBoxRepository : IBaseRepository<Wms_inventorybox>
    {
    }
}