﻿using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_CarrierRepository : IBaseRepository<Wms_Carrier>
    {
    }
}
