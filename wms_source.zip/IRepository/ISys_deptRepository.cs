using YL.Core.Entity;

namespace IRepository
{
    public interface ISys_deptRepository : IBaseRepository<Sys_dept>
    {
    }
}