using YL.Core.Entity;

namespace IRepository
{
    public interface ISys_logRepository : IBaseRepository<Sys_log>
    {
    }
}