using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_reservoirareaRepository : IBaseRepository<Wms_reservoirarea>
    {
    }
}