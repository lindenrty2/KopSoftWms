using YL.Core.Entity;

namespace IRepository
{
    public interface IWms_materialRepository : IBaseRepository<Wms_material>
    {
    }
}