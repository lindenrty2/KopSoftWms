using YL.Core.Entity;

namespace IRepository
{
    public interface ISys_rolemenuRepository : IBaseRepository<Sys_rolemenu>
    {
    }
}